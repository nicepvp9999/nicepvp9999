
const mineflayer = require('mineflayer');
const express = require('express');
const { Client, GatewayIntentBits } = require('discord.js');
require('dotenv').config();

const DISCORD_TOKEN = process.env.DISCORD_TOKEN;
const CHANNEL_ID = process.env.CHANNEL_ID;

const MINECRAFT_HOST = process.env.MINECRAFT_HOST;
const MINECRAFT_USERNAME = process.env.MINECRAFT_USERNAME;
const MINECRAFT_VERSION = process.env.MINECRAFT_VERSION;

const discordClient = new Client({
  intents: [
    GatewayIntentBits.Guilds,
    GatewayIntentBits.GuildMessages,
    GatewayIntentBits.MessageContent,
  ],
});

let bot;

function startMinecraftBot() {
  bot = mineflayer.createBot({
    host: MINECRAFT_HOST,
    username: MINECRAFT_USERNAME,
    version: MINECRAFT_VERSION,
  });

  bot.on('login', () => {
    console.log('Minecraft bot başarıyla giriş yaptı!');
    bot.chat('/login anya66+66');
    setTimeout(() => bot.chat('/is go'), 3000);
  });

  bot.on('chat', (username, message) => {
    if (username !== bot.username) {
      const channel = discordClient.channels.cache.get(CHANNEL_ID);
      if (channel) {
        channel.send(`[${username}]: ${message}`);
      }
    }
  });

  bot.on('end', () => {
    console.log('Bot bağlantısı kesildi. Yeniden bağlanıyor...');
    startMinecraftBot();
  });

  bot.on('error', (err) => {
    console.log(`Hata oluştu: ${err.message}`);
  });
}

discordClient.on('messageCreate', (message) => {
  if (message.channel.id === CHANNEL_ID && !message.author.bot) {
    const discordMessage = message.content.trim();
    bot.chat(discordMessage); // Discord mesajını Minecraft sohbetine gönderir
    console.log(`Discord -> Minecraft: ${discordMessage}`);
  }
});

discordClient.once('ready', () => {
  console.log(`Discord botu giriş yaptı: ${discordClient.user.tag}`);
  startMinecraftBot();
});

discordClient.login(DISCORD_TOKEN);

// Express.js Keep-Alive servisi
const app = express();
app.get('/', (req, res) => res.send('Bot aktif ve çalışıyor!'));
app.listen(3000, () => console.log('Keep-Alive servisi başlatıldı.'));
